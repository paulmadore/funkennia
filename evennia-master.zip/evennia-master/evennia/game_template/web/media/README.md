This directory is where file uploads from Django apps are placed by
default.
