You can replace the CSS files for Evennia's homepage here.

You can find the original files in `evennia/web/static/website/css/`
