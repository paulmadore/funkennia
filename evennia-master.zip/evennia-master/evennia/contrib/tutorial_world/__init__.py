# -*- coding: utf-8 -*-
"""
This package holds the demo game of Evennia.
"""
from __future__ import absolute_import

from . import mob, objects, rooms

