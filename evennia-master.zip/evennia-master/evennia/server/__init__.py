"""
This sub-package holds the Server and Portal programs - the "core" of
Evennia. It also contains the SessionHandler that manages all
connected users as well as defines all the connection protocols used
to connect to the game.

"""
