"""
This sub-package holds the Scripts system. Scripts are database
entities that can store data both in connection to Objects and Players
or globally. They may also have a timer-component to execute various
timed effects.

"""
