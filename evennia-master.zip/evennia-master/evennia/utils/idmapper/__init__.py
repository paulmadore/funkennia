"""
The idmapper holds the main database caching mechanism.
"""
