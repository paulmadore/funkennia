# encoding=utf-8
"""
Test form
"""

FORMCHAR = "x"
TABLECHAR = "c"

FORM = """
.------------------------------------------------.
|                                                |
|  Name: xxxxx1xxxxx    Player: xxxxxxx2xxxxxxx  |
|        xxxxxxxxxxx                             |
|                                                |
 >----------------------------------------------<
|                                                |
| Desc:  xxxxxxxxxxx    STR: x4x    DEX: x5x     |
|        xxxxx3xxxxx    INT: x6x    STA: x7x     |
|        xxxxxxxxxxx    LUC: x8x    MAG: x9x     |
|                                                |
 >----------.-----------------------------------<
|           |                                    |
| ccccccccc | cccccccccccccccccccccccccccccccccc |
| ccccccccc | cccccccccccccccccccccccccccccccccc |
| cccAccccc | cccccccccccccccccccccccccccccccccc |
| ccccccccc | cccccccccccccccccccccccccccccccccc |
| ccccccccc | ccccccccccccccccBccccccccccccccccc |
|           |                                    |
 -----------`-------------------------------------
"""


