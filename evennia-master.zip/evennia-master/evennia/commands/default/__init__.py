"""
This package contains all default commands of Evennia, grouped after category.
"""
