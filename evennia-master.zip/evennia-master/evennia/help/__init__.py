"""
This sub-package defines the help system of Evennia. It is pretty
simple, mainly consisting of a database model to hold help entries.
The auto-cmd-help is rather handled by the default 'help' command
itself.

"""
