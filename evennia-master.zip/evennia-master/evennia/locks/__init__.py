# -*- coding: utf-8 -*-
"""
This sub-package defines the lock (access) mechanism of Evennia. All
lock strings are processed through the lockhandler in this package. It
also contains the default lock functions used in lock definitions.

"""
