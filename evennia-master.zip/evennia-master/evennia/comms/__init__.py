"""
This sub-package contains Evennia's comms-system, a set of models and
handlers for in-game communication via channels and messages as well
as code related to external communication like IRC or RSS.

"""
